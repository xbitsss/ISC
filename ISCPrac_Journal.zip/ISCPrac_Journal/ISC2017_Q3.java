package ISCPrac_Journal;

import java.util.*;
public class ISC2017_Q3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        encrypt(s);

    }

    private static void encrypt(String s) {
        String ans = "";
        int l = s.length();
        for(int i=0;i<l;i++) {
            char ch = s.charAt(i);
                if(ch>=65&&ch<78||ch>=97&&ch<110)
                    ans = ans+(char)(ch+13);
                else if(ch>=78&&ch<91||ch>=110&&ch<123)
                    ans = ans+(char)(ch-13);
                else
                    ans = ans+ch;
        }
        System.out.println("The cipher text is: \n"+ans);

    }

}
