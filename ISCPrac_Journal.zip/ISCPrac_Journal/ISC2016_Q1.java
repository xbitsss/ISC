package ISCPrac_Journal;

import java.util.*;
public class ISC2016_Q1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n = sc.nextInt();
        if(isCyclicPrime(n))
            System.out.println("Cyclic Prime");
        else
            System.out.println("Not a cyclic prime");

    }

    private static boolean isCyclicPrime(int n) {

        String temp = String.valueOf(n);
        boolean flag = true;
        for(int i=0;i<temp.length();i++) {

            int x = shift(n,i);
            System.out.println(x);
            if(!isPrime(x))
                flag = false;
        }
        return flag;

    }

    private static int shift(int n,int i) {
        String s = String.valueOf(n);
        return Integer.parseInt(s.substring(i)+s.substring(0,i));


    }
    private static boolean isPrime(int n) {

        for(int i=2;i<n;i++)
            if(n%i == 0)
                return false;
            return true;

    }

}
