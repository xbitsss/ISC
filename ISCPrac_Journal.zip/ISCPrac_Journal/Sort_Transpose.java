package ISCPrac_Journal;

import java.util.*;
public class Sort_Transpose {

    int arr[][];
    int m,n;

    public static void main(String[] args)
    {
        Sort_Transpose ob = new Sort_Transpose();
        ob.accept();
        ob.sort();
        ob.printTranspose();
    }
    private void printArray()
    {
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
                System.out.print(String.format("%-5d",arr[i][j]));
            System.out.println();
        }
    }
    private void accept()
    {
        Scanner sc = new Scanner((System.in));
        System.out.println("Enter the size");
        m = sc.nextInt();
        n = sc.nextInt();
        arr = new int[m][n];
        System.out.println("Enter the elements");
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                arr[i][j] = sc.nextInt();
            System.out.println("The original matrix is");
            printArray();
    }
    private void sort()
    {
        int a[] = new int[m*n];
        // Rearranging elements in a single dimension array
        int k = 0;
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++,k++)
                a[k] = arr[i][j];

            // Sorting the array using Bubble Sort technique

        for(int i=0;i<(m*n)-1;i++)
        {
            for(int j=0;j<(m*n)-1-i;j++)
            {
                if(a[j]<a[j+1])
                {
                    int t = a[j];
                    a[j] = a[j+1];
                    a[j+1] = t;
                }
            }
        }

        // Reassigning the values
        k = 0;
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++,k++)
                arr[i][j] = a[k];

            System.out.println("The sorted matrix is");
            printArray();
    }

    private void printTranspose()
    {
        System.out.println("Transpose Matrix");
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
                System.out.print(String.format("%-5d",arr[j][i]));
            System.out.println();
        }
    }

}
