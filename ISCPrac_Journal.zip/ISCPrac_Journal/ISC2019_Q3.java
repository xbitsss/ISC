package ISCPrac_Journal;

import java.util.*;
public class ISC2019_Q3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        char c = s.charAt(s.length()-1);
        if(s.toUpperCase().equals(s) && (c == '!'|| c == '.' || c == '?')) {
            StringTokenizer st = new StringTokenizer(s," ?.!");
            int l = st.countTokens();
            for(int i=0;i<l;i++) {

                String wrd = st.nextToken();
                if(!isPalindrome(wrd))
                wrd = getPalindromeWord(wrd);
                System.out.print(wrd+" ");
            }
            System.out.println();

        }
        else
            System.out.println("INVALID INPUT");
    }

    private static String getPalindromeWord(String wrd) {

        String ans;
        int l = wrd.length();
        int[] range = new int[2];
        char lchar = wrd.charAt(l-1);
        for(int i=l-2;i>=0;i--) {

            if(wrd.charAt(i) == lchar)
                range[1] = i;
            else {
                range[1] = i;
                break;
            }

        }
        ans = wrd.substring(0,l);
        for(int i=range[1];i>=range[0];i--)
            ans += wrd.charAt(i);

        return ans;

    }

    private static boolean isPalindrome(String wrd) {

        String rev = "";
        for(int i=0;i<wrd.length();i++)
            rev = wrd.charAt(i)+rev;

        return wrd.equalsIgnoreCase(rev);

    }


}
