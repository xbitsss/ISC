package ISCPrac_Journal;

import java.util.*;
public class countVowels {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        System.out.println("The number of vowels in the string are:");
        System.out.println(getVowelCount(s));

    }
    private static int getVowelCount(String s) {

        int ctr = 0;
        for(int i=0;i<s.length();i++) {
            if(s.toUpperCase().charAt(i) == 'A' || s.toUpperCase().charAt(i) == 'E' || s.toUpperCase().charAt(i) == 'I' || s.toUpperCase().charAt(i) == 'O' || s.toUpperCase().charAt(i) == 'U')
                ctr++;
        }

        return ctr;
    }

}
