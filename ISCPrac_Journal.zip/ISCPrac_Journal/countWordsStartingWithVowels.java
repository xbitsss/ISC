package ISCPrac_Journal;

import java.util.*;
public class countWordsStartingWithVowels {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        System.out.println("The number of words starting with a vowel are:");
        System.out.println(getNumberOfWordsStartingWithVowels(s));


    }
    private static int getNumberOfWordsStartingWithVowels(String s) {

        int ctr = 0;
        StringTokenizer st = new StringTokenizer(s, " ");
        int l = st.countTokens();
        for(int i=0;i<l;i++) {

            String a = st.nextToken();
            if(a.toUpperCase().startsWith("A") || a.toUpperCase().startsWith("E") || a.toUpperCase().startsWith("I") || a.toUpperCase().startsWith("O") || a.toUpperCase().startsWith("U"))
               ctr++;
        }

        return ctr;
    }

}
