package ISCPrac_Journal;

import java.util.*;
public class CircularPrime {

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n = sc.nextInt();
        if(isPrime(n) && isPrime(reverse(n)))
            System.out.println("Circular Prime Number");
        else
            System.out.println("Not a Circular Prime Number");
    }
    private static boolean isPrime(int n)
    {
        for(int i=2;i<n;i++)
            if(n%i==0)
                return false;
            return true;
    }
    private static int reverse(int n)
    {
        int temp = n,rev = 0,d;
        while(temp>0)
        {
            d = temp%10;
            rev = rev*10+d;
            temp/=10;
        }
        return rev;
    }

}
