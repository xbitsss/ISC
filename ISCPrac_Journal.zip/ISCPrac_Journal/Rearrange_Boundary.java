package ISCPrac_Journal;

import java.util.*;
public class Rearrange_Boundary {

    int arr[][];
    int m,n;

    public static void main(String[] args)
    {
        Rearrange_Boundary ob = new Rearrange_Boundary();
        ob.accept();
        ob.rearrangeBoundaryAndPrint();
    }

    private void printArray()
    {
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
                System.out.printf("%-5d",arr[i][j]);
            System.out.println();
        }
    }

    private void accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the matrix");
        m = sc.nextInt();
        n = sc.nextInt();
        arr = new int[m][n];
        System.out.println("Enter the elements");
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                arr[i][j] = sc.nextInt();
            System.out.println("The original matrix is");
            printArray();

    }

    private void rearrangeBoundaryAndPrint()
    {
        int sum = 0;
        int ct = 0;
        int a[];
        // Calculating the sum and number of boundary elements
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(i==0||i==m-1||j==0||j==n-1)
                {
                    ct++;
                    sum += arr[i][j];
                }
            }
        }
        // Initialising and extracting the boundary elements
        a = new int[ct];
        int k = 0;
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                if(i==0||i==m-1||j==0||j==n-1)
                {
                    a[k] = arr[i][j];
                    k++;
                }
        // Sorting the boundary elements
        a = sort(a);
        // Rearranging after sorting
        k=0;
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                if(i==0||i==m-1||j==0||j==n-1)
                {
                    arr[i][j] = a[k];
                    k++;
                }

        System.out.println("Rearranged Matrix with sorted boundary elements");
        printArray();
        System.out.println("Sum of boundary elements = "+sum);

    }

    private int[] sort(int a[])
    {
        for(int i=0;i<a.length-1;i++)
        {
            for(int j=0;j<a.length-1-i;j++)
            {
                if(a[j]>a[j+1])
                {
                    int t = a[j];
                    a[j] = a[j+1];
                    a[j+1] = t;
                }
            }
        }
        return a;
    }
}
