package ISCPrac_Journal;

import java.util.*;
public class ISC2016_Q2 {

    static int arr[][];
    static int m;
    public static void main(String[] args) {

        Scanner sc= new Scanner(System.in);
        System.out.println("Enter M");
        m = sc.nextInt();
        if(m>3&&m<10) {
            arr = new int[m][m];
            System.out.println("Enter elements");
            for(int i=0;i<m;i++)
                for(int j=0;j<m;j++)
                    arr[i][j] = sc.nextInt();
                System.out.println("ORIGINAL MATRIX");
                printMatrix();
                tally();

        }
        else
            System.out.println("MATRIX SIZE OUT OF RANGE");

    }
    private static void tally() {

        int ctr = 0;
        for(int i=0;i<m;i++)
            for(int j=0;j<m;j++)
                if(i==0||i==m-1||j==0||j==m-1)
                    ctr++;

                int k =0;
                int a[] = new int[ctr];

        for(int i=0;i<m;i++)
            for(int j=0;j<m;j++)
                if(i==0||i==m-1||j==0||j==m-1) {
                    a[k] = arr[i][j];
                }
        System.out.println("REARRANGED MATRIX");
        sort(a);
        printMatrix();

        int sum = 0;
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
                if(i==j||(i+j) == m-1) {
                    System.out.printf("%-5d", arr[i][j]);
                    sum += arr[i][j];
                }
                else
                    System.out.printf("%-5d"," ");
            System.out.println();
        }

        System.out.println("SUM OF DIAGONAL ELEMENTS: "+sum);


    }

    private static void printMatrix() {

        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
                System.out.printf("%-5d",arr[i][j]);
            System.out.println();
        }

    }

    private static void sort(int a[]) {

        for(int i=0;i<m-1;i++)
            for(int j=0;j<m-i-1;j++)
                if(a[j]>a[j+1]) {
                    int t = a[j];
                    a[j] = a[j+1];
                    a[j+1]  = t;

                }

    }


}
