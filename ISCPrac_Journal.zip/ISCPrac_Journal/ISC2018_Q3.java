package ISCPrac_Journal;

import java.util.*;
public class ISC2018_Q3 {

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of teams N");
        int n = sc.nextInt();
        if(n>2&&n<9) {
            String[] arr = new String[n];
            for(int i=0;i<n;i++) {

                System.out.println("Team "+(i+1)+": ");
                arr[i] = sc.nextLine();
                if(i==0)
                    arr[i] = sc.nextLine();
            }
            design(arr,n);

        }
        else
            System.out.println("Invalid Input");

    }

    private static void design(String[] arr, int n) {

        boolean flag[] = new boolean[n];
        for(int k=0;;k++) {
            for(int i=0;i<n;i++) {
                if(arr[i].length() > k)
                    System.out.print(arr[i].charAt(k) + "\t");
                else if(arr[i].length() <= k) {
                    flag[i] = true;
                    System.out.print("\t");
                }
            }
            if(isComplete(flag,n))
                break;
            System.out.println();
        }
    }
    private static boolean isComplete(boolean[] flag, int n) {
        for(int i=0;i<n;i++)
            if(!flag[i])
                return false;
            return true;
    }

}
