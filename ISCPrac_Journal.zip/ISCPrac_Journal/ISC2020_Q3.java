package ISCPrac_Journal;

import java.util.*;
public class ISC2020_Q3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a sentence");
        String s = sc.nextLine();
        if(s.endsWith(".")||s.endsWith("?")||s.endsWith("!")) {

            System.out.println(s);
            sortAndDisplay(s);
        }
        else
            System.out.println("INVALID INPUT");

    }

    private static void sortAndDisplay(String s) {

        StringTokenizer st = new StringTokenizer(s," !?.");
        int l =st.countTokens();
        String arr[] = new String[l];
        for(int i=0;i<l;i++)
            arr[i] = st.nextToken();

        sort(arr);
        for(int i=0;i<l;i++)
            System.out.print(arr[i]+" ");

    }

    private static void sort(String[] arr) {

        int l = arr.length;
        for(int i=0;i<l-1;i++) {
            for(int j=0;j<l-1-i;j++) {
                if(arr[j].length()>arr[j+1].length()) {
                    String t = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = t;
                }
                else if (arr[j].length() == arr[j+1].length())
                if(arr[j].compareTo(arr[j+1]) > 0) {
                    String t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }

    }

}
