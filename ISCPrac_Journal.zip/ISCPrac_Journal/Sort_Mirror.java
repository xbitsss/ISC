package ISCPrac_Journal;

import java.util.*;
public class Sort_Mirror
{
    int[][] arr;
    int m,n;
    Sort_Mirror()
    {
        m=0;
        n=0;
    }
    public static void main(String[] args)
    {
        Sort_Mirror ob = new Sort_Mirror();
        ob.accept();
        ob.sortArray();
        ob.printMirrorImage();
        
    }
    private void accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        m = sc.nextInt();
        n = sc.nextInt();
        arr = new int[m][n];
        System.out.println("Enter the array elements");
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                arr[i][j] = sc.nextInt();
        System.out.println("The Original Matrix is");
        printArray();

    }
    private void printArray()
    {
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
                System.out.printf("%-5d",arr[i][j]);
            System.out.println();
        }
    }
    private void sortArray()
    {
        int[] a = new int[m*n];
        // Arranging the elements into a Single Dimension Array
        int k = 0;
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++,k++)
                a[k] = arr[i][j];

        // Sorting the array using Selection Sort
        for (int i = 0; i < a.length-1; i++)
        {
            int min_idx = i;
            for (int j = i+1; j < a.length; j++)
                if (a[j] < a[min_idx])
                    min_idx = j;


            int temp = a[min_idx];
            a[min_idx] = a[i];
            a[i] = temp;
        }
        // Arranging the elements in a matrix format
        k=0;
        for(int i=0;i<m;i++)
            for (int j=0;j<n;j++,k++)
                arr[i][j] = a[k];

            System.out.println("The sorted matrix is");
            printArray();
    }
    private void printMirrorImage()
    {
        System.out.println("The Mirror Image is");
        for(int i=0;i<m;i++)
        {
            for(int j=n-1;j>=0;j--)
                System.out.printf("%-5d",arr[i][j]);
            System.out.println();
        }
    }

}