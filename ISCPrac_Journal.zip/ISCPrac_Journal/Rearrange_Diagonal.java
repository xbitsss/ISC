package ISCPrac_Journal;

import java.util.*;
public class Rearrange_Diagonal {

    int arr[][];
    int n;
    public static void main(String[] args)
    {
        Rearrange_Diagonal ob = new Rearrange_Diagonal();
        ob.accept();
        ob.rearrangeDiagonalAndPrint();
    }

    private void printArray()
    {
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
                System.out.printf("%-5d",arr[i][j]);
            System.out.println();
        }
    }

    private void accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        n = sc.nextInt();
        arr = new int[n][n];
        System.out.println("Enter the elements");
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                arr[i][j] = sc.nextInt();

            System.out.println("The original matrix is");
            printArray();

    }

    private void rearrangeDiagonalAndPrint()
    {
        int a[] = new int[n];
        int sum = 0;
        int ct = 0;
        int k = 0;
        // Calculating the sum and extracting the diagonal elements
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(i==j||(i+j) == n-1)
                {
                    a[k] = arr[i][j];
                    sum += arr[i][j];
                    k++;
                }
            }
        }

        // Sorting the diagonal elements
        a = sort(a);
        // Rearranging after sorting
        k=0;
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                if(i==j||(i+j) == n-1)
                {
                    arr[i][j] = a[k];
                    k++;
                }

        System.out.println("Rearranged Matrix with sorted diagonal elements");
        printArray();
        System.out.println("Sum of diagonal elements = "+sum);
    }

    private int[] sort(int a[])
    {
        for(int i=0;i<a.length-1;i++)
        {
            for(int j=0;j<a.length-1-i;j++)
            {
                if(a[j]<a[j+1])
                {
                    int t = a[j];
                    a[j] = a[j+1];
                    a[j+1] = t;
                }
            }
        }
        return a;
    }

}
