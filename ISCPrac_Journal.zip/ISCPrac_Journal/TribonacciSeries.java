package ISCPrac_Journal;

import java.util.*;
public class TribonacciSeries {

    public static void main(String[] args)
    {
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter a number");
       int n = sc.nextInt();
       printTriboSeries(n);
    }
    private static void printTriboSeries(int n)
    {
        int a = 0;
        int b = 1;
        int c = 2;
        int z = 0;
        System.out.print(a+" "+b+" "+c);
        while(z<n)
        {
            z = a+b+c;
           System.out.print(" "+z);
           a = b;
           b = c;
           c = z;
        }
    }

}
