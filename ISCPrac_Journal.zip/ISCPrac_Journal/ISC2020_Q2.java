package ISCPrac_Journal;

import java.util.*;
public class ISC2020_Q2 {

    static int m,n;
    static int arr[][];
    public static void main(String[] args) {

        accept();
    }

    private static void accept() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter m and n");
        m = sc.nextInt();
        n = sc.nextInt();

        boolean flag = true;

        if(m>0&&m<10&&n>2&&n<6) {

            arr = new int[m][n];
            for (int i = 0; i < m; i++) {

                System.out.println("ENTER ELEMENTS FOR ROW " + (i+1));
                for (int j = 0; j < n; j++) {
                    arr[i][j] = sc.nextInt();
                    if (arr[i][j] < 0 || arr[i][j] >= 8)
                        flag = false;
                }
            }

            if(!flag)
                System.out.println("INVALID INPUT");
            else
                designMatrix();
        }
    }

    private static void designMatrix() {

        System.out.println("FILLED MATRIX\t\t\t\tDECIMAL EQUIVALENT");
        for(int i=0;i<m;i++)
        {
            int sum = 0;
            for(int j=0;j<n;j++) {

                System.out.print(String.format("%-5d",arr[i][j]));
                sum += getDecimalEquivalent(arr[i][j],n-j-1);

            }
            System.out.print("\t\t\t\t"+sum);
            System.out.println();
        }

    }
    private static int getDecimalEquivalent(int x,int i) {

        return (int)Math.pow(8,i) * x;

    }
}
