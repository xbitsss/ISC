package ISCPrac_Journal;

import java.util.*;
public class ISC2017_Q2 {

    static char arr[][];
    static char key[];
    static int score[];
    static String[] p;
    static int n;
    public static void main(String[] args) {

        accept();
    }

    private static void accept() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter N");
        n = sc.nextInt();
        if(n>3&&n<10){
            arr = new char[n][5];
            key = new char[5];
            score = new int[n];
            p = new String[n];
            System.out.println("Enter the opts");
            for(int i=0;i<n;i++)
                for(int j=0;j<5;j++)
                    arr[i][j] = sc.next().charAt(0);
                System.out.println("Enter the key");
                for(int i=0;i<5;i++)
                key[i] = sc.next().charAt(0);
                validate();

        }
        else
            System.out.println("INPUT SIZE OUT OF RANGE");

    }

    private static void validate() {

        for(int i=0;i<n;i++)
            for(int j=0;j<5;j++)
                if(arr[i][j] == key[j])
                    score[i]++;


                System.out.println("Scores: ");
                for(int i=0;i<n;i++) {
                    System.out.println("Participant "+(i+1)+": "+score[i]);
                    p[i] = "Participant "+(i+1);
                }


                sort();
        System.out.println("Highest Scores: ");
        for(int i=0;i<n;i++)
            if(arr[i] != arr[i+1]) {
                System.out.println(p[i]);
                break;
            }
        else
            System.out.println(p[i]);


    }

    private static void sort() {

        for(int i=0;i< score.length-1;i++)
            for(int j=0;j< score.length-1-i;j++)
                if(score[j]<score[j+1]) {
                    int t = score[j];
                    score[j] = score[j+1];
                    score[j+1] = t;

                    String t2 = p[j];
                    p[j] = p[j+1];
                    p[j+1] = t2;
                }

    }

}
