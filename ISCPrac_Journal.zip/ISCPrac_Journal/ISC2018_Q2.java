package ISCPrac_Journal;

import java.util.*;
public class ISC2018_Q2 {

    static int arr[][];
    static int m,n;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter M and N");
        m = sc.nextInt();
        n = sc.nextInt();
        if(m>2&&m<10&&n>2&&n<10) {
            System.out.println("Enter elements");
            arr = new int[m][n];
            for(int i=0;i<m;i++)
                for(int j=0;j<n;j++)
                    arr[i][j] = sc.nextInt();

                System.out.println("ORIGINAL MATRIX:");
                printMatrix();
                System.out.println("MATRIX WITH SORTED ROWS");
                designMatrix();
        }
        else
            System.out.println("MATRIX SIZE OUT OF RANGE");

    }

    private static void designMatrix() {

        int a[];
        for(int i=0;i<m;i++) {
            a  = arr[i];
            BSort(a);
            arr[i] = a;
        }
        printMatrix();

    }

    private static void printMatrix() {

        for(int i=0;i<m;i++) {
            for(int j=0;j<n;j++)
                System.out.print(String.format("%-5d",arr[i][j]));
            System.out.println();
        }

    }

    private static void BSort(int a[]) {

        for(int i = 0;i<a.length-1;i++)
            for(int j=0;j<a.length-1-i;j++)
                if(a[j]>a[j+1]) {
                    int t= a[j];
                    a[j] = a[j+1];
                    a[j+1] = t;
                }

    }

}
