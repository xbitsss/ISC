package ISCPrac_Journal;

import java.util.*;
public class Rotate90 {

    int arr[][];
    int m,n;

    public static void main(String args[])
    {
        Rotate90 ob = new Rotate90();
        ob.accept();
        ob.printRotate90();
    }

    private void printArray()
    {
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
                System.out.printf("%-5d",arr[i][j]);
            System.out.println();
        }
    }

    private void accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        m = sc.nextInt();
        n = sc.nextInt();
        arr = new int[m][n];
        System.out.println("Enter the elements");
        for(int i=0;i<m;i++)
            for(int j=0;j<n;j++)
                arr[i][j] = sc.nextInt();
            System.out.println("The original matrix is");
            printArray();

    }
    private void printRotate90()
    {
        int temp[][]  = new int[n][m];
        System.out.println("The rotated matrix by 90 is");
        for(int i=n-1,a =0 ;i>=0;i--, a++)
        {
            for(int j=0,b=0;j<m;j++,b++) {
                temp[a][b] = arr[j][i];
                System.out.printf("%-5d",arr[j][i]);
            }
            System.out.println();
        }
        arr = new int[n][m];
        int c = n;
        n = m;
        m = c;
        arr = temp;
        System.out.println("The rotated matrix by 90 is");
        printArray();
    }

}
