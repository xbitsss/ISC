package ISCPrac_Journal;

import java.util.*;
public class ReverseString {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        System.out.println("Reversed String");
        System.out.println(getReversed(s));

    }
    private static String getReversed(String s) {

        String ans = "";
        StringTokenizer st = new StringTokenizer(s," ");
        int l = st.countTokens();
        for(int i=0;i<l;i++) {

            String a = st.nextToken();
            a = reverse(a);
            ans += a+" ";
        }
        return ans;
    }

    private static String reverse(String s) {
        String rev = "";
        for(int i=0;i<s.length();i++)
            rev = s.charAt(i)+rev;
        return rev;
    }

}
