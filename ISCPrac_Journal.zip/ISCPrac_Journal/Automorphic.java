package ISCPrac_Journal;

import java.util.*;
public class Automorphic {

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n = sc.nextInt();
        if(isAutomorphic(n))
            System.out.println("Automorphic Number");
        else
            System.out.println("Not an Automorphic Number");

    }
    private static boolean isAutomorphic(int n)
    {
        String squaredNumber = String.valueOf(n*n);
        return squaredNumber.endsWith(String.valueOf(n));
    }

}
