package ISCPrac_Journal;

import java.util.*;
public class ISC2020_Q1 {

    public static void main(String args[]) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the range");
        int m = sc.nextInt();
        int n = sc.nextInt();
        int ctr = 0;
        if(m<n) {
            System.out.println("THE PRIME-ADAM INTEGERS ARE:");
            for(int i=m;i<=n;i++) {

                if(isPrime(i) && isAdam(i)) {
                    ctr++;
                    System.out.print(i+" ");
                }

            }
            System.out.println();
            if(ctr!=0)
                System.out.println("THE FREQUENCY OF ADAM INTEGERS IS: "+ctr);
            else{
                System.out.println("NIL");
                System.out.println("THE FREQUENCY OF ADAM INTEGERS IS: "+ctr);
            }

        }
        else
            System.out.println("INVALID INPUT");


    }

    private static boolean isAdam(int n) {

        return n*n == reverse(reverse(n)*reverse(n));

    }

    private static boolean isPrime(int n) {

        for(int i=2;i<n;i++)
            if(n%i==0)
                return false;
            return true;

    }

    private static int reverse(int n) {

        int d,rev = 0;
        while(n>0) {

            d = n%10;
            rev = rev*10+d;
            n/=10;

        }
        return rev;

    }

}
