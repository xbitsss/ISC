package ISCPrac_Journal;

import java.util.*;
public class ISC2018_Q1 {

    static int arr[];

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n = sc.nextInt();
        if(n>9&&n<50) {

            if(n%2 == 0) {

                getPrime();
                System.out.println("PRIME PAIRS ARE: ");
                getGoldbachPairs(n);
            }
            else
                System.out.println("INVALID INPUT. NUMBER IS ODD");

        }
        else
            System.out.println("INVALID INPUT. NUMBER OUT OF RANGE");

    }

    private static void getGoldbachPairs(int k) {

        for(int i=0;i<arr.length;i++)
            for(int j=i;j< arr.length;j++)
                if(arr[i]+arr[j] == k)
                    System.out.println(arr[i]+","+arr[j]);

    }

    private static void getPrime() {

        int ctr = 0;

        for(int i=2;i<50;i++)
            if(isPrime(i))
                ctr++;

            arr = new int[ctr];
            int k = 0;
        for(int i=2;i<50;i++)
            if(isPrime(i)) {
                arr[k] = i;
                k++;
            }


    }

    private static boolean isPrime(int n) {

        for(int i=2;i<n;i++)
            if(n%i==0)
                return false;
            return true;

    }


}
