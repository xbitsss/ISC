package ISCPrac_Journal;

import java.util.*;
public class endWithVowel {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array");
        int size = sc.nextInt();
        String arr[] = new String[size];
        System.out.println("Enter the words");
        for(int i=0;i<size;i++)
            arr[i] = sc.next();
        System.out.println("The words ending in vowels are:");
        System.out.println(getWordsEndingWithVowels(arr));


    }
    private static String getWordsEndingWithVowels(String[] arr) {

        String wrdsEndingInVowels = "";
        for(int i=0;i<arr.length;i++)
            if(arr[i].toUpperCase().endsWith("A") || arr[i].toUpperCase().endsWith("E") || arr[i].toUpperCase().endsWith("I") || arr[i].toUpperCase().endsWith("O") || arr[i].toUpperCase().endsWith("U"))
                wrdsEndingInVowels += arr[i]+" ";

        return wrdsEndingInVowels;

    }

}
