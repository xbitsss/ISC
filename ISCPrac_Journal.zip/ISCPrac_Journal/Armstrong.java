package ISCPrac_Journal;

import java.util.*;
public class Armstrong {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n = sc.nextInt();
        if(isArmstrong(n))
            System.out.println("Armstrong Number");
        else
            System.out.println("Not an Armstrong Number");


    }
    private static boolean isArmstrong(int n) {

        int temp = n,soc = 0,d;
        while(temp>0) {

            d = temp%10;
            soc+= d*d*d;
            temp/=10;
        }

        return soc == n;
    }

}
