package ISCPrac_Journal;



import java.util.Scanner;
public class SmithNumber {

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n = sc.nextInt();
        if(sumOfFactors(n) == sumOfDigits(n))
            System.out.println("Smith Number");
        else
            System.out.println("Not a Smith Number");
    }

    private static int sumOfFactors(int n)
    {
        int sum = 0, temp = n;

            for(int i=n-1;i>=2;i--)
                if(n%i==0 && isPrime(i)) {
                    while(temp%i == 0)
                    {
                        System.out.println(i);
                        sum += sumOfDigits(i);
                        temp /= i;
                    }

                }
        return sum;
    }


    private static boolean isPrime(int n) {

        for(int i=2;i<n;i++)
            if(n%i==0)
                return false;
            return true;
    }

    private static int sumOfDigits(int n)
    {
        int temp = n,sum = 0;
        while(temp>0)
        {
            sum += temp%10;
            temp/=10;
        }
        return sum;
    }

}
