package ISCPrac_Journal;

import java.util.*;
public class ISC2019_Q1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("DAY NUMBER: ");
        int day = sc.nextInt();
        System.out.println("YEAR: ");
        int year = sc.nextInt();
        System.out.println("DATE AFTER (N DAYS)");
        int ndays = sc.nextInt();
        if(day>=1&&day<=366) {
            if(ndays>=1&&ndays<=100) {

            }
            else
                System.out.println("DATE AFTER (N DAYS) OUT OF RANGE");
        }
        else
            System.out.println("DATE NUMBER OUT OF RANGE");

    }

    private static void getDate(int year, int ndays, int day) {
        int y = 0;
        int dayLeft = day;
        String date = "";
        String postfix = "";
        if(!isLeapYear(year)) {
            int i = 0;
            for(i=1;i< monthDays.length;i++) {
                if(dayLeft < monthDays[i]) {
                    if(dayLeft == 1||dayLeft == 21|| dayLeft == 31)
                        postfix = "ST";
                    else if(dayLeft == 2||dayLeft == 22)
                        postfix = "ND";
                    else if(dayLeft == 3||dayLeft == 23)
                        postfix = "RD";
                    else
                        postfix = "TH";
                    break;
                }
                else
                    dayLeft -= monthDays[i];
            }
            date = dayLeft+postfix+" "+monthDays[i]+", "+year;
            System.out.println(date);
            for(;i< monthDays.length;i++) {
                if(i == monthDays.length -1 && dayLeft + ndays > monthDays[i]) {
                    dayLeft -= monthDays[i] - dayLeft;
                    y+=1;
                    i = 1;
                }
                else if(dayLeft + ndays > monthDays[i]) {
                    dayLeft -= monthDays[i] - dayLeft;
                    i++;
                    continue;
                }
            }
        }
        else {


        }

    }

    private static boolean isLeapYear(int year) {

        if(year%400 == 0)
            return true;
        else if(year%100 == 0)
            return false;
        else if(year%4 == 0)
            return true;
        else
            return false;
    }

    static int monthDays[] = {0,31,28,31,30,30,30,31,31,30,31,30,31};
    static int leapmonthDays[] = {0,31,29,31,30,30,30,31,31,30,31,30,31};
    static String month[] = {"January","February","March","April","May","June","July","August","September","October","November","December"};

}
