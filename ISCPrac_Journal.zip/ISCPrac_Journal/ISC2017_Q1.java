package ISCPrac_Journal;

import java.util.*;
public class ISC2017_Q1 {

    static int sizeUsed[] = {0,0,0,0};
    static int sizes[] = {48,24,12,6};
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the N");
        int n = sc.nextInt();
        solve(n);

    }
    private static void solve(int n) {

        int temp = n;
        int cartonUsed = 0;
        for(int i=0;i<4;i++) {

            while(true)
                if(n-sizes[i] < 0)
                    break;
                else {
                    n -= sizes[i];
                    cartonUsed++;
                    sizeUsed[i]++;
                }
        }
        for(int i=0;i<4;i++) {
            if(sizeUsed[i] !=0)
            System.out.println(sizes[i]+" * "+sizeUsed[i]+" = "+sizes[i]*sizeUsed[i]);
        }
        if(n == 0)
        System.out.println("Remaining boxes = 0");
        else
            System.out.println("Remaining boxes = "+n+"*1");
        System.out.println("Total number of boxes = "+(temp-n));
        System.out.println("Total number of cartons = "+cartonUsed);

    }

}
