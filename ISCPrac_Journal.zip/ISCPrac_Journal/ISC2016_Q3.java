package ISCPrac_Journal;

import java.util.*;
public class ISC2016_Q3 {

    public static void main(String[] args) {

        Scanner sc= new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        solve(s);

    }

    private static void solve(String s) {

        StringTokenizer st = new StringTokenizer(s," ?.!");
        int l =st.countTokens();
        String ans = "";;
        String v = "";
        int ctr = 0;
        String p = "";
        for(int i=0;i<l;i++) {

            String a = st.nextToken();
            a = a.toUpperCase();
            char c = a.charAt(0);
            char c2 = a.charAt(a.length()-1);
            if(c == 'A'||c=='E'||c=='I'||c=='O'||c=='U') {
                ctr++;
                if (c2 == 'A' || c2 == 'E' || c2 == 'I' || c2 == 'O' || c2 == 'U')
                    v += a+" ";
                else
                    p+=a+" ";
            }
            else
                 p +=a+" ";


        }
        ans = v+p;
        System.out.println("THE WORD STARTING WITH VOWELS ARE: "+ctr);
        System.out.println(ans);


    }

}
