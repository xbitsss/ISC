package ISCPrac_Journal;

import java.util.*;
public class ISC2019_Q2 {

    int[] a;
    int[][] b;
    int N  = 0;

    public static void main(String[] args) {

        ISC2019_Q2 ob = new ISC2019_Q2();
        ob.accept();

    }

    private void accept() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size N");
        N = sc.nextInt();
        if(N>2&&N<10) {
            a = new int[N];
            b = new int[N][N];
            System.out.println("ENTER ELEMENTS OF SINGLE DIMENSIONAL ARRAY");
            for(int i=0;i<N;i++)
                a[i] = sc.nextInt();

            designMatrix();
            printOutput();
        }
        else
            System.out.println("MATRIX SIZE OUT OF RANGE");


    }

    private void designMatrix() {

        BSort();
        for(int i=0;i<N;i++) {
            for(int j=0,k=0;j<N-i;j++,k++)
                b[i][j] = a[k];

            for(int k=N-i,l=0;k<N;k++,l++)
                b[i][k] = a[l];
        }

    }

    private void printOutput() {

        System.out.print("The Sorted Array is: ");
        for(int i=0;i<N;i++)
        System.out.print(a[i]+" ");
        System.out.println();

        System.out.println("FILLED MATRIX:");

        for(int i=0;i<N;i++) {
            for(int j=0;j<N;j++)
                System.out.print(String.format("%-5d",b[i][j]));
            System.out.println();
        }

    }

    private void BSort() {

        for(int i=0;i<N-1;i++)
            for(int j=0;j<N-1-i;j++)
                if(a[j]>a[j+1]) {
                    int t = a[j];
                    a[j] = a[j+1];
                    a[j+1] = t;
                }

    }

}
