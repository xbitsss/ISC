package ISCPrac_Journal;

import java.util.*;
public class StringPalindrome {

    public static void main(String args[]) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        System.out.println("The Palindrome Words in the given string are:");
        System.out.println(getPalindromeWords(s));
    }

    private static String getPalindromeWords(String s) {

        StringTokenizer st = new StringTokenizer(s," ");
        String palinWrds ="";
        int l = st.countTokens();
        for(int i=0;i<l;i++) {
            String a = st.nextToken();
            if(isPalindrome(a))
                palinWrds += a+ " ";
        }
        return palinWrds;
    }

    private static boolean isPalindrome(String wrd) {

        String rev = "";
        for(int i=0;i<wrd.length();i++)
            rev = wrd.charAt(i)+rev;

        return rev.equalsIgnoreCase(wrd);
    }

}
